package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val boton1:Button=findViewById(R.id.Comparar)
        boton1.setOnClickListener { Nombre()}
    }

    private fun Nombre() {


        val lblNombre:TextView=findViewById(R.id.lblRespuesta)
        val campoNombre: EditText=findViewById(R.id.editTextNombre )
        var nombre=campoNombre.text
        lblNombre.text=nombre
        Toast.makeText(this,"Hola!!! soy: $nombre",Toast.LENGTH_LONG).show()
    }
}
